import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/scss/main.css';
import './sw.js';

