import $ from 'jquery';
const dataResto = require('../DATA.json');
import { async } from 'regenerator-runtime';

const menu = $('#menu');
const drawer = $('#drawer');
const hero = $('.hero');
const main = $('main');

menu.click((event) => {
    // drawer.classList.toggle('open');
    drawer.toggleClass('open');
    event.stopPropagation();
});

hero.click(() => {
    drawer.removeClass('open');
});

main.click(() => {
    drawer.removeClass('open');
});


const renderAllResto = () => {
    const listRestoElement = document.querySelector('.restov');
    listRestoElement.innerHTML = '';

    dataResto.restaurants.forEach(resto => {

        listRestoElement.innerHTML += `
            <article class="resto-item" tabindex="0">
                <img src="${resto.pictureId}"
                    alt="Restaurant"
                    class="resto-item_thumbnail">
                <p class="resto-item_location">${resto.city}</p>
                <div class="resto-item_content">
                    <div>
                        <h1 class="resto-item_title">${resto.name}</h1>
                        <p class="resto-item_description">${resto.description}</p>
                    </div>
                    <p class="resto-item_rate"><span><i class="fas fa-star"></i> ${resto.rating}</span></p>
                </div>
            </article>
        `;
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const buttonLearn = $('#learn-more');
    const dev_info = $('.info');
    const mainContent = $('.headline_desctiption');

    dev_info.hide();

    buttonLearn.click(() => {
        
        dev_info.slideDown(1000);
        dev_info.fadeOut(5000);
    });

    renderAllResto();
})